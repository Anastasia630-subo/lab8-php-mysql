<?php
require dirname(__DIR__).'/app/bootstrap.php';
$u=currentUser();postOnly();csrf();
$id=uid($_POST['uid']??null);
$r=userOperation((int)$u['id'],$id,'view');
if (!$r) fail(404,'Устройство не найдено');
if ($r['outcome']!=='allowed') fail(429,'Доступ временно заблокирован');
if ($r['state']['role']!=='operator') fail(403,'Недостаточно прав');
$c=json_decode(file_get_contents(dirname(__DIR__).'/var/demo_credentials.json'),true,16,JSON_THROW_ON_ERROR);
foreach($c['devices'] as $d) {
 if($d['uid']!==$id) continue;
 $s=$r['state'];
 $result=deviceOperation($id,$d['token'],['Term'=>$s['temperature']===null?216:(int)round((float)$s['temperature']*10),'Rele'=>(int)($s['command']??$s['relay']??0)]);
 if($result['code']!==200)fail($result['code'],$result['text']);
 header('Location: index.php',true,303);exit;
}
fail(404,'Симулятор устройства не найден');
