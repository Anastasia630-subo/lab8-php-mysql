<?php
require dirname(__DIR__).'/app/bootstrap.php';
startSession();
if ((int)query('SELECT COUNT(*) FROM users')->fetchColumn()!==0) fail(404,'Установка уже выполнена');
if ($_SERVER['REQUEST_METHOD']!=='POST') {
 page('Подготовка лабораторной',function(){ ?>
 <form method="post" class="login"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>">
 <p>Создать учебных пользователей и три устройства в новой базе лабораторной 8.</p>
 <button>Создать учебные данные</button></form>
 <?php }); exit;
}
csrf();
$pdo = db(); $pdo->beginTransaction();
try {
    $password = 'Demo_251361!';
    foreach (['nastya','viewer','other'] as $name) {
        query('INSERT INTO users (username,password_hash) VALUES (?,?)',
            [$name, password_hash($password, PASSWORD_DEFAULT)]);
    }
    $users = query('SELECT id,username FROM users ORDER BY id')->fetchAll();
    $devices = [];
    foreach (['Комната','Теплица','Чужое устройство'] as $name) {
        $uid = bin2hex(random_bytes(16)); $token = bin2hex(random_bytes(32));
        query('INSERT INTO devices (uid,name,token_hash) VALUES (?,?,?)',
            [$uid, $name, hash('sha256', $token)]);
        $id = (int)$pdo->lastInsertId();
        query('INSERT INTO device_state (device_id) VALUES (?)', [$id]);
        $devices[] = ['id'=>$id, 'uid'=>$uid, 'token'=>$token, 'name'=>$name];
    }
    foreach ([$devices[0],$devices[1]] as $d) {
        query('INSERT INTO device_access (user_id,device_id,role) VALUES (?,?,?)',
            [$users[0]['id'],$d['id'],'operator']);
    }
    query('INSERT INTO device_access (user_id,device_id,role) VALUES (?,?,?)',
        [$users[1]['id'],$devices[0]['id'],'viewer']);
    query('INSERT INTO device_access (user_id,device_id,role) VALUES (?,?,?)',
        [$users[2]['id'],$devices[2]['id'],'operator']);
    $pdo->commit();
    $path = dirname(__DIR__) . '/var/demo_credentials.json';
    file_put_contents($path, json_encode(['password'=>$password,'users'=>$users,'devices'=>$devices],
        JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    chmod($path, 0600);
    deviceOperation($devices[0]['uid'],$devices[0]['token'],['Term'=>216,'Rele'=>0]);
    deviceOperation($devices[1]['uid'],$devices[1]['token'],['Term'=>184,'Rele'=>1]);
    unlink(__FILE__);
    header('Location: login.php',true,303); exit;
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
}
