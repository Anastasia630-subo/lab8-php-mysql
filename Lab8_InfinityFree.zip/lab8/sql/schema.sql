-- Версия для InfinityFree: таблицы без VIEW и триггеров. Блокировки реализованы в PHP.
SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(64) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE devices (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uid CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    last_seen DATETIME(6) NULL,
    window_start DATETIME(6) NULL,
    request_count INT UNSIGNED NOT NULL DEFAULT 0,
    blocked_until DATETIME(6) NULL
) ENGINE=InnoDB;

CREATE TABLE device_access (
    user_id BIGINT UNSIGNED NOT NULL,
    device_id BIGINT UNSIGNED NOT NULL,
    role VARCHAR(16) NOT NULL DEFAULT 'operator',
    window_start DATETIME(6) NULL,
    request_count INT UNSIGNED NOT NULL DEFAULT 0,
    blocked_until DATETIME(6) NULL,
    PRIMARY KEY (user_id, device_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (device_id) REFERENCES devices(id),
    CONSTRAINT ck_access_role CHECK (role IN ('viewer', 'operator'))
) ENGINE=InnoDB;

CREATE TABLE device_state (
    device_id BIGINT UNSIGNED PRIMARY KEY,
    temperature DECIMAL(5,1) NULL,
    relay TINYINT NULL,
    command TINYINT NULL,
    temperature_at DATETIME(6) NULL,
    relay_at DATETIME(6) NULL,
    command_at DATETIME(6) NULL,
    FOREIGN KEY (device_id) REFERENCES devices(id),
    CHECK (temperature IS NULL OR temperature BETWEEN -55 AND 125),
    CHECK (relay IS NULL OR relay IN (0,1)),
    CHECK (command IS NULL OR command IN (0,1))
) ENGINE=InnoDB;

CREATE TABLE user_events (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    device_id BIGINT UNSIGNED NOT NULL,
    action VARCHAR(16) NOT NULL,
    command TINYINT NULL,
    happened_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    outcome VARCHAR(24) NOT NULL DEFAULT 'allowed',
    FOREIGN KEY (user_id, device_id) REFERENCES device_access(user_id, device_id),
    CHECK (action IN ('view','history','control')),
    CHECK (command IS NULL OR command IN (0,1)),
    CHECK ((action = 'control' AND command IS NOT NULL)
        OR (action <> 'control' AND command IS NULL)),
    CHECK (outcome IN ('allowed','user_blocked','device_blocked','forbidden')),
    INDEX ix_user_history (device_id, happened_at, id)
) ENGINE=InnoDB;

CREATE TABLE device_events (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_id BIGINT UNSIGNED NOT NULL,
    happened_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    outcome VARCHAR(16) NOT NULL DEFAULT 'allowed',
    FOREIGN KEY (device_id) REFERENCES devices(id),
    CHECK (outcome IN ('allowed','blocked')),
    INDEX ix_device_history (device_id, happened_at, id)
) ENGINE=InnoDB;

