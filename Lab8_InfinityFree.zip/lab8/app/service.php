<?php
declare(strict_types=1);

// InfinityFree: ограничения выполняются в PHP, а не SQL-триггерами.
function userOperation(int $userId, string $uid, string $action, ?int $command = null): ?array {
    $pdo = db(); $pdo->beginTransaction();
    try {
        $d = query('SELECT id,(blocked_until > UTC_TIMESTAMP(6)) AS blocked FROM devices WHERE uid=? FOR UPDATE', [$uid])->fetch();
        $a = $d ? query('SELECT role,request_count,(blocked_until > UTC_TIMESTAMP(6)) AS blocked,
            (window_start IS NULL OR UTC_TIMESTAMP(6) >= window_start + INTERVAL 60 SECOND) AS reset_window
            FROM device_access WHERE user_id=? AND device_id=? FOR UPDATE', [$userId,$d['id']])->fetch() : false;
        if (!$d || !$a) { $pdo->rollBack(); return null; }
        if ($action === 'control' && $a['role'] !== 'operator') {
            $outcome = 'forbidden';
        } elseif ($a['blocked']) {
            $outcome = 'user_blocked';
        } else {
            $n = $a['reset_window'] ? 1 : (int)$a['request_count'] + 1;
            query('UPDATE device_access SET window_start=IF(?,UTC_TIMESTAMP(6),window_start),request_count=?,
                blocked_until=IF(?,UTC_TIMESTAMP(6) + INTERVAL 60 SECOND,NULL) WHERE user_id=? AND device_id=?',
                [(int)$a['reset_window'],$n,(int)($n > 10),$userId,$d['id']]);
            $outcome = $n > 10 ? 'user_blocked' : ($d['blocked'] ? 'device_blocked' : 'allowed');
        }
        query('INSERT INTO user_events (user_id,device_id,action,command,outcome) VALUES (?,?,?,?,?)',
            [$userId,$d['id'],$action,$command,$outcome]);
        if ($outcome !== 'allowed') { $pdo->commit(); return ['outcome'=>$outcome]; }
        if ($action === 'control') query('UPDATE device_state SET command=?,command_at=UTC_TIMESTAMP(6) WHERE device_id=?', [$command,$d['id']]);
        $state = query('SELECT a.user_id,a.role,a.blocked_until AS user_blocked_until,
            d.id,d.uid,d.name,d.last_seen,d.blocked_until AS device_blocked_until,
            s.temperature,s.relay,s.command,s.temperature_at,s.relay_at,s.command_at
            FROM device_access a JOIN devices d ON d.id=a.device_id
            JOIN device_state s ON s.device_id=d.id WHERE a.user_id=? AND d.id=?', [$userId,$d['id']])->fetch();
        $history = $action === 'history' ? query('SELECT e.happened_at,u.username,e.action,e.command,e.outcome
            FROM user_events e JOIN users u ON u.id=e.user_id WHERE e.device_id=? ORDER BY e.id DESC LIMIT 100', [$d['id']])->fetchAll() : [];
        $pdo->commit(); return ['outcome'=>'allowed','state'=>$state,'history'=>$history];
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
}

function deviceOperation(string $uid, string $token, array $data): array {
    $pdo = db(); $pdo->beginTransaction();
    try {
        $d = query('SELECT id,token_hash,request_count,(blocked_until > UTC_TIMESTAMP(6)) AS blocked,
            (window_start IS NULL OR UTC_TIMESTAMP(6) >= window_start + INTERVAL 60 SECOND) AS reset_window
            FROM devices WHERE uid=? FOR UPDATE', [$uid])->fetch();
        if (!$d || !hash_equals($d['token_hash'],hash('sha256',$token))) {
            $pdo->rollBack(); return ['code'=>401,'text'=>'Неверные реквизиты устройства'];
        }
        $blocked = (bool)$d['blocked'];
        if (!$blocked) {
            $n = $d['reset_window'] ? 1 : (int)$d['request_count'] + 1; $blocked = $n > 30;
            query('UPDATE devices SET window_start=IF(?,UTC_TIMESTAMP(6),window_start),request_count=?,
                blocked_until=IF(?,UTC_TIMESTAMP(6) + INTERVAL 60 SECOND,NULL) WHERE id=?',
                [(int)$d['reset_window'],$n,(int)$blocked,$d['id']]);
        }
        query('INSERT INTO device_events (device_id,outcome) VALUES (?,?)', [$d['id'],$blocked ? 'blocked' : 'allowed']);
        if ($blocked) { $pdo->commit(); return ['code'=>429,'text'=>'Устройство временно заблокировано']; }
        if (array_key_exists('Term',$data)) query('UPDATE device_state SET temperature=?,temperature_at=UTC_TIMESTAMP(6) WHERE device_id=?', [$data['Term'] === null ? null : $data['Term']/10,$d['id']]);
        if (array_key_exists('Rele',$data)) query('UPDATE device_state SET relay=?,relay_at=UTC_TIMESTAMP(6) WHERE device_id=?', [$data['Rele'],$d['id']]);
        query('UPDATE devices SET last_seen=UTC_TIMESTAMP(6) WHERE id=?', [$d['id']]);
        $state = query('SELECT command FROM device_state WHERE device_id=?', [$d['id']])->fetch();
        $pdo->commit(); return ['code'=>200,'text'=>'COMMAND ' . ($state['command'] ?? '?') . ' EOC'];
    } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
}
