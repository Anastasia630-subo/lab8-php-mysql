<?php
declare(strict_types=1);
// Реквизиты используются на том же сервере, без вывода пароля в браузер.
$previous = require dirname(__DIR__,2).'/site/app/config.local.php';
return [
 'dsn'=>'mysql:host=sql111.infinityfree.com;port=3306;dbname=if0_43522104_lab8;charset=utf8mb4',
 'user'=>$previous['mysql']['username'],
 'password'=>$previous['mysql']['password'],
];
